#!/bin/sh

set -a

USERNAME=$1

PROPERTIES_DIR=${PWD}/../properties
SCRIPTS_PY_DIR=${PWD}/../scripts_py
SCRIPTS_SH_DIR=${PWD}/../scripts_sh
PAAS_LOGS_DIR=${PWD}/../paas_logs

cd $SCRIPTS_SH_DIR
$SCRIPTS_SH_DIR/unmask_password.sh $USERNAME PASSWORD

. $PROPERTIES_DIR/domain.properties
. $PROPERTIES_DIR/users/$USERNAME
. $DOMAIN_HOME/bin/setDomainEnv.sh

DATE_TIME=`date +"[%m-%d-%Y] [%r]"`
echo -n "$DATE_TIME [`basename $0`] [UserName=$USERNAME] [DomainName=$DOMAIN_NAME] " >> $PAAS_LOGS_DIR/build.log

$JAVA_HOME/bin/java -classpath $WEBLOGIC_HOME/server/lib/weblogic.jar -Djava.security.egd=file:/dev/./urandom -Dweblogic.management.confirmKeyfileCreation=true weblogic.WLST -skipWLSModuleScanning ${SCRIPTS_PY_DIR}/createConfigKeyFiles.py $USERNAME $PASSWORD $DOMAIN_NAME >> ${PAAS_LOGS_DIR}/wlst_createConfigKeyFiles.log 2>&1 

if [ $? -eq 2 ]
then
        echo -e "\t[Status=ERROR]" >> $PAAS_LOGS_DIR/build.log
else
        echo -e "\t[Status=SUCCESS]" >> $PAAS_LOGS_DIR/build.log
fi

cd $SCRIPTS_SH_DIR
$SCRIPTS_SH_DIR/mask_password.sh $USERNAME PASSWORD
