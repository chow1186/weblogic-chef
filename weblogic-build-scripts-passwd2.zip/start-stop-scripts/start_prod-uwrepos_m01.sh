#!/bin/sh

DOMAIN_NAME=prod-uwrepos
DOMAIN_HOME=/tech/appl/cds9/user_projects/prod-uwrepos
SERVER_NAME=prod-uwrepos_m01

PRODUCTION_MODE="true"

LOG_HOME=/tech/appl/cds9/dailylog/prod-uwrepos/prod-uwrepos_m01

ADMIN_URL="t3s://lad1wlahp2009:21401"

. ${DOMAIN_HOME}/bin/setDomainEnv.sh

AUDIT_LOG_DIR=/tech/appl/cds9/dailylog/prod-uwrepos
JAVA_OPTIONS="${JAVA_OPTIONS}  -Dweblogic.security.audit.auditLogDir=${AUDIT_LOG_DIR} -Dweblogic.security.SSL.ignoreHostnameVerification=true  -Djava.security.egd=file:/dev/./urandom -Dapp.environment=prod -Dapp.logdir=$DOMAIN_HOME/logs/$SERVER_NAME/app_logs -Dpaas.buildVersion=5.0 -Dmode=PROD  "

MEM_ARGS="-Xms1024m -Xmx1024m -XX:MaxPermSize=256m -Xverify:none -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:${LOG_HOME}/${SERVER_NAME}_gc.log.`date +%Y%m%d-%H%M` -XX:+DisableExplicitGC -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=${LOG_HOME}/heap_dumps  "

PAAS_PRE_CLASSPATH=
PAAS_POST_CLASSPATH=

CLASSPATH="${PAAS_PRE_CLASSPATH}:${CLASSPATH}:${PAAS_POST_CLASSPATH}"

echo "tail -f ${LOG_HOME}/prod-uwrepos_m01.log"

echo "/usr/bin/nohup ${JAVA_HOME}/bin/java ${JAVA_VM} ${MEM_ARGS} -Dweblogic.Name=${SERVER_NAME} -Dweblogic.management.server=${ADMIN_URL} -Dweblogic.system.BootIdentityFile=${DOMAIN_HOME}/boot.properties -Dweblogic.ProductionModeEnabled=${PRODUCTION_MODE} -Djava.security.policy=${WL_HOME}/server/lib/weblogic.policy ${JAVA_OPTIONS} ${SERVER_CLASS} > /dev/null 2>&1 & " > ${LOG_HOME}/StartUpCommand.log

env | grep -v ADMIN_PASSWORD > ${DOMAIN_HOME}/instance_envs/${SERVER_NAME}.env

/usr/bin/nohup ${JAVA_HOME}/bin/java ${JAVA_VM} ${MEM_ARGS} -Dweblogic.Name=${SERVER_NAME} -Dweblogic.management.server=${ADMIN_URL} -Dweblogic.system.BootIdentityFile=${DOMAIN_HOME}/boot.properties -Dweblogic.ProductionModeEnabled=${PRODUCTION_MODE} -Djava.security.policy=${WL_HOME}/server/lib/weblogic.policy ${JAVA_OPTIONS} ${SERVER_CLASS} > /dev/null 2>&1 & 

