#!/bin/sh

PROPERTIES_DIR=${PWD}/../properties
SCRIPTS_PY_DIR=${PWD}/../scripts_py
SCRIPTS_SH_DIR=${PWD}/../scripts_sh
PAAS_LOGS_DIR=${PWD}/../paas_logs

. $PROPERTIES_DIR/domain.properties


instance_name=$1
INSTANCE_FILE=`find ${PROPERTIES_DIR} -name $instance_name`

SCRIPT_NAME=start_$instance_name.sh
. ${INSTANCE_FILE}

DATE_TIME=`date +"[%m-%d-%Y] [%r]"`
echo "$DATE_TIME [`basename $0`] [InstanceName=$instance_name]" >> $PAAS_LOGS_DIR/build.log

cat > ${SCRIPT_NAME} <<EOF
#!/bin/sh

DOMAIN_NAME=${DOMAIN_NAME}
DOMAIN_HOME=${DOMAIN_HOME}
SERVER_NAME=${instance_name}

PRODUCTION_MODE="true"

LOG_HOME=${DAILYLOG_DIRECTORY}/${instance_name}

EOF

if [ $instance_name != ${DOMAIN_NAME}_admin ]; then
	ADMIN_URL=\"${ADMIN_PROTOCOL}://${ADMIN_HOST}:${ADMIN_PORT}\"
	echo "ADMIN_URL=${ADMIN_URL}" >> ${SCRIPT_NAME}
fi


COMMON_JAVA_OPTIONS=`cat ${PROPERTIES_DIR}/commonJavaOptions.properties | tr -s '\n' ' ' `
TEMP_JAVA_OPTIONS="\${JAVA_OPTIONS} $COMMON_JAVA_OPTIONS $CUSTOM_JAVA_OPTIONS"
COMMON_MEM_ARGS=`cat ${PROPERTIES_DIR}/commonMemArgs.properties | tr -s '\n' ' ' `
TEMP_MEM_ARGS="$COMMON_MEM_ARGS $CUSTOM_MEM_ARGS"

cat >> ${SCRIPT_NAME} <<EOF

. \${DOMAIN_HOME}/bin/setDomainEnv.sh

JAVA_OPTIONS="${TEMP_JAVA_OPTIONS} "

MEM_ARGS="-Xms${MIN_HEAP}m -Xmx${MAX_HEAP}m -XX:MaxPermSize=${MAX_PERM}m $TEMP_MEM_ARGS"

PAAS_PRE_CLASSPATH=$PAAS_PRE_CLASSPATH
PAAS_POST_CLASSPATH=$PAAS_POST_CLASSPATH

CLASSPATH="\${PAAS_PRE_CLASSPATH}:\${CLASSPATH}:\${PAAS_POST_CLASSPATH}"

echo "tail -f \${LOG_HOME}/$instance_name.log"

echo "${START_COMMAND}" > \${LOG_HOME}/StartUpCommand.log

env | grep -v ADMIN_PASSWORD > \${DOMAIN_HOME}/instance_envs/\${SERVER_NAME}.env

${START_COMMAND}

EOF

chmod 750 ${SCRIPT_NAME}

if [ ! -d $DOMAIN_HOME/scripts/backups ]
then
	mkdir -p $DOMAIN_HOME/scripts/backups
fi

if [ -f $DOMAIN_HOME/scripts/$SCRIPT_NAME ] 
then
	mv $DOMAIN_HOME/scripts/$SCRIPT_NAME $DOMAIN_HOME/scripts/backups/$SCRIPT_NAME.`date +%Y%m%d-%H%M`
fi
mv $SCRIPT_NAME $DOMAIN_HOME/scripts


