#!/bin/sh

# Setup paths that hold the property files along with shell and python scripts
# Note that SCRIPTS_SH_DIR points to the same directory from where we are executing this file
# Has been added for readability and to have a seamless way of calling logMessage.sh
PROPERTIES_DIR=${PWD}/../properties
SCRIPTS_PY_DIR=${PWD}/../scripts_py
SCRIPTS_SH_DIR=${PWD}/../scripts_sh
PAAS_LOGS_DIR=${PWD}/../paas_logs

# Source the domain.properties file so that we have everything that's needed for invoking python scripts
# Note we are not going to invoke any python scripts for importing certificates but this line
# has been retained for readability and consistency purposes
. $PROPERTIES_DIR/domain.properties

DATE_TIME=`date +"[%m-%d-%Y] [%r]"`
echo -e "$DATE_TIME [`basename $0`] [User=$USERNAME] [DomainName=$DOMAIN_NAME]" >> $PAAS_LOGS_DIR/build.log

CERT_NAME=$1

# Source the property file for the certificate so that we can get the alias_name
. $PROPERTIES_DIR/certificates/$CERT_NAME

# List the certs
$JAVA_HOME/bin/keytool -list -keystore ${KEY_STORE} -storepass ${STORE_PASSWORD} -alias ${ALIAS_NAME} | grep "<${ALIAS_NAME}> does not exist" > /dev/null 2>&1
if [[ $? = 0 ]]
then
  # Adding -noprompt to avoid getting prompted for yes/no
  $JAVA_HOME/bin/keytool -noprompt -import -v -trustcacerts -alias ${ALIAS_NAME} -file ${CERT_FILE} -keystore ${KEY_STORE} -storepass ${STORE_PASSWORD}
else
  echo Alias ${ALIAS_NAME} already exists in ${KEY_STORE}
fi

$SCRIPTS_SH_DIR/mask_password.sh $CERT_NAME STORE_PASSWORD
exit 0
