import os
import sys
from java.io import FileInputStream

def str2bool(v):
    return v.lower() in ("yes", "true", "t", "1")

JDBC_DATASOURCE_NAME = sys.argv[1]
readDomain(os.environ['DOMAIN_HOME'])

propertiesStream = FileInputStream(os.environ['PROPERTIES_DIR']+"/jdbc/" +JDBC_DATASOURCE_NAME)
properties = Properties()
properties.load(propertiesStream)

ADMIN_URL = "t3://" + os.environ['ADMIN_HOST'] + ":" + os.environ['ADMIN_PORT']

JDBC_DATASOURCE_NAME=properties.get("JDBC_DATASOURCE_NAME")
JDBC_JNDI_NAME=properties.get("JDBC_JNDI_NAME")
JDBC_DATASOURCE_URL=properties.get("JDBC_DATASOURCE_URL")
JDBC_DRIVER_NAME=properties.get("JDBC_DRIVER_NAME")
JDBC_PASSWORD=properties.get("JDBC_PASSWORD")
JDBC_USERNAME=properties.get("JDBC_USERNAME")
JDBC_TARGETS=properties.get("JDBC_TARGETS")
JDBC_INITIAL_CAPACITY=properties.get("JDBC_INITIAL_CAPACITY")
JDBC_CAPACITY_INCREMENT=properties.get("JDBC_CAPACITY_INCREMENT")
JDBC_MAX_CAPACITY=properties.get("JDBC_MAX_CAPACITY")
JDBC_TEST_TABLE_NAME=properties.get("JDBC_TEST_TABLE_NAME")
JDBC_TEST_CONNECTIONS_ON_RESERVE=properties.get("JDBC_TEST_CONNECTIONS_ON_RESERVE")
JDBC_CONNECTION_CREATION_RETRY_FREQUENCY=properties.get("JDBC_CONNECTION_CREATION_RETRY_FREQUENCY")

print "-----------------------------------------------------------------------------"
print "DATASOURCE_NAME: \t" + JDBC_DATASOURCE_NAME
print "JNDI_NAME: \t" + JDBC_JNDI_NAME
print "DATASOURCE_URL: \t" + JDBC_DATASOURCE_URL
print "DRIVER_NAME: \t" + JDBC_DRIVER_NAME
print "USERNAME: \t" + JDBC_USERNAME
print "TARGETS: \t" + JDBC_TARGETS
print "INITIAL CAPACITY: \t" + JDBC_INITIAL_CAPACITY
print "MAX CAPACITY: \t" + JDBC_MAX_CAPACITY
print "-----------------------------------------------------------------------------"


try:
	connect(url=ADMIN_URL)
	edit()
	startEdit()
	cd('/')
	print "Checking if datasource already exists"
	try:
		LOOKUP_RESULT=lookup(JDBC_DATASOURCE_NAME,'JDBCSystemResource')
	except:
		print 'Datasouce does not exist...Creating.'
		cmo.createJDBCSystemResource(JDBC_DATASOURCE_NAME)
        	cd('/JDBCSystemResources/' + JDBC_DATASOURCE_NAME + '/JDBCResource/' + JDBC_DATASOURCE_NAME)
        	cmo.setName(JDBC_DATASOURCE_NAME)
        	cd('/JDBCSystemResources/' + JDBC_DATASOURCE_NAME + '/JDBCResource/' + JDBC_DATASOURCE_NAME+ '/JDBCDriverParams/' + JDBC_DATASOURCE_NAME + '/Properties/' + JDBC_DATASOURCE_NAME)
        	cmo.createProperty('user')
	else:
		print "Datasource by this name already exists in the domain. Updating properties"

	#cmo.createJDBCSystemResource(JDBC_DATASOURCE_NAME)
	cd('/JDBCSystemResources/' + JDBC_DATASOURCE_NAME + '/JDBCResource/' + JDBC_DATASOURCE_NAME)
	cmo.setName(JDBC_DATASOURCE_NAME)

	cd('/JDBCSystemResources/' + JDBC_DATASOURCE_NAME + '/JDBCResource/' + JDBC_DATASOURCE_NAME + '/JDBCDataSourceParams/' + JDBC_DATASOURCE_NAME)
	set('JNDINames',jarray.array([String(JDBC_JNDI_NAME)], String))

	cd('/JDBCSystemResources/' + JDBC_DATASOURCE_NAME + '/JDBCResource/' + JDBC_DATASOURCE_NAME + '/JDBCDriverParams/' + JDBC_DATASOURCE_NAME)
	cmo.setUrl(JDBC_DATASOURCE_URL)
	cmo.setDriverName(JDBC_DRIVER_NAME)
	set('Password',JDBC_PASSWORD)
	cd('/JDBCSystemResources/' + JDBC_DATASOURCE_NAME + '/JDBCResource/' + JDBC_DATASOURCE_NAME + '/JDBCConnectionPoolParams/' + JDBC_DATASOURCE_NAME)
	cmo.setTestTableName(JDBC_TEST_TABLE_NAME)
	cmo.setTestConnectionsOnReserve(str2bool(JDBC_TEST_CONNECTIONS_ON_RESERVE))
	cmo.setMaxCapacity(int(JDBC_MAX_CAPACITY))
	cmo.setCapacityIncrement(int(JDBC_CAPACITY_INCREMENT))
	cmo.setInitialCapacity(int(JDBC_INITIAL_CAPACITY))
	cmo.setConnectionCreationRetryFrequencySeconds(int(JDBC_CONNECTION_CREATION_RETRY_FREQUENCY))

	cd('/JDBCSystemResources/' + JDBC_DATASOURCE_NAME + '/JDBCResource/' + JDBC_DATASOURCE_NAME + '/JDBCDriverParams/' + JDBC_DATASOURCE_NAME + '/Properties/' + JDBC_DATASOURCE_NAME + '/Properties/user')
	cmo.setValue(JDBC_USERNAME)

	cd('/JDBCSystemResources/' + JDBC_DATASOURCE_NAME + '/JDBCResource/' + JDBC_DATASOURCE_NAME + '/JDBCDataSourceParams/' + JDBC_DATASOURCE_NAME)
	cmo.setGlobalTransactionsProtocol('OnePhaseCommit')

	cd('/SystemResources/' + JDBC_DATASOURCE_NAME)
	##set('Targets',jarray.array([ObjectName('com.bea:Name=JDBC_TARGETS,Type=Server')], ObjectName))
	#set('Targets',jarray.array([ObjectName('com.bea:Name=' + JDBC_TARGETS + ',Type=Server')], ObjectName))
	TARGETS_LIST = JDBC_TARGETS.split(',')
	for target in TARGETS_LIST:
	   print target.strip()
	   svr = getMBean("/Servers/"+target.strip())
	   cmo.addTarget(svr)

	activate()
        disconnect()
        exit()
except:
        exit(exitcode=2)
