# ##########################################################################
# Change Default Logging Configuration for the domain and all instances
# Usage : setupLogging.py <Name of Properties file >
# #########################################################################
import sys
from java.io import FileInputStream

#read properties file

if len(sys.argv) != 2:
	print "Invalid Arguements :: Usage setupLogging.py < Logging Properties file>"
	exit()

def editBegin():
	edit()
	startEdit()

def editEnd():
	save()
	activate(block="true")

def updateDomainLogSettings(logBean):
	logBean.setRotationType(properties.get("ROTATION_TYPE"))
	logBean.setNumberOfFilesLimited(str2bool(properties.get("LIMIT_LOG_FILE_COUNT")))
	logBean.setFileCount(int(properties.get("LOG_FILE_COUNT")))
	logBean.setRotateLogOnStartup(str2bool(properties.get("ROTATE_LOG_ON_STARTUP")))
	logBean.setFileName(os.environ['DAILYLOG_DIRECTORY'] + "/" + logBean.getName() + '.log')

def str2bool(v):
    return v.lower() in ("yes", "true", "t", "1")

propertiesStream = FileInputStream(sys.argv[1])
properties = Properties()
properties.load(propertiesStream)

ADMIN_URL = "t3://" + os.environ['ADMIN_HOST'] + ":" + os.environ['ADMIN_PORT']

print "-----------------------------------------------------------------------------"
print "Domain Log Settings: "
input_file = open(sys.argv[1], 'r')
for line in input_file:
    print line
input_file.close()
print "-----------------------------------------------------------------------------"

#Connect
try:
	connect(url=ADMIN_URL)
	domainConfig()
	editBegin()
	logBean = getMBean('/Log/' + cmo.getName())
	updateDomainLogSettings(logBean)
	editEnd()
	disconnect()
        exit(defaultAnswer='y')
except:
        exit(exitcode=2,defaultAnswer='y')


