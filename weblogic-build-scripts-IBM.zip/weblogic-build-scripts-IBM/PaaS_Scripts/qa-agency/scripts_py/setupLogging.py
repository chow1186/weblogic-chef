# ##########################################################################
# Change Default Logging Configuration for the domain and all instances
# Usage : setupLogging.py <Name of Properties file >
# #########################################################################
import sys
from java.io import FileInputStream

if len(sys.argv) != 2:
	print "Invalid Arguements :: Usage setupLogging.py < Logging Properties file>"
	exit()

def editBegin():
	edit()
	startEdit()

def editEnd():
	save()
	activate(block="true")

def updateDomainLogSettings(logBean):
	print "************************************************"
	print "Updating Log setting for (" + logBean.getName() + ")"
	print "************************************************"
	print ""
	logBean.setRotationType(properties.get("domain.rotationType"))
	logBean.setNumberOfFilesLimited(str2bool(properties.get("domain.limitLogFileCount")))
	logBean.setFileCount(int(properties.get("domain.logFileCount")))
	logBean.setRotateLogOnStartup(str2bool(properties.get("domain.rotateLogOnStartup")))
	logBean.setFileName(properties.get("domain.logdir") + '/' + logBean.getName() + '.log')

def str2bool(v):
    return v.lower() in ("yes", "true", "t", "1")

def updateInstanceLogSettings(logBean):
	print "************************************************"
	print "Updating Log setting for (" + logBean.getName() + ")"
	print "************************************************"
	print ""
	logBean.setRotationType(properties.get("instance.rotationType"))
	logBean.setNumberOfFilesLimited(str2bool(properties.get("instance.limitLogFileCount")))
	logBean.setFileCount(int(properties.get("instance.logFileCount")))
	logBean.setRotateLogOnStartup(str2bool(properties.get("instance.rotateLogOnStartup")))
	logBean.setFileName(properties.get("domain.logdir") + '/' + logBean.getName() + '/' + logBean.getName() + '.log')
	logBean.setLoggerSeverity(properties.get("instance.loggerSeverity"))
	logBean.setDomainLogBroadcastSeverity(properties.get("instance.domainLogBroadcastSeverity"))
	logBean.setStdoutSeverity(properties.get("instance.stdoutSeverity"))
	logBean.setLogFileSeverity(properties.get("instance.logFileSeverity"))
	logBean.setMemoryBufferSeverity(properties.get("instance.memoryBufferSeverity"))
	logBean.setRedirectStdoutToServerLogEnabled(str2bool(properties.get("instance.redirectStdoutLoggingEnabled")))
	logBean.setRedirectStderrToServerLogEnabled(str2bool(properties.get("instance.redirectStderrLoggingEnabled")))
	httplogBean = getMBean('/Servers/' + logBean.getName() + '/WebServer/' + logBean.getName() + '/WebServerLog/' + logBean.getName())
	httplogBean.setRotationType(properties.get("instance.rotationType"))
    httplogBean.setNumberOfFilesLimited(str2bool(properties.get("instance.limitLogFileCount")))
    httplogBean.setFileCount(int(properties.get("instance.logFileCount")))
    httplogBean.setRotateLogOnStartup(str2bool(properties.get("instance.rotateLogOnStartup")))
    httplogBean.setFileName(properties.get("domain.logdir") + '/' + logBean.getName() + '/' + 'access.log')

propertiesStream = FileInputStream(sys.argv[1])
properties = Properties()
properties.load(propertiesStream)

#Connect
try:
	connect(properties.get("domain.username"), properties.get("domain.password"), properties.get("domain.adminurl"))

	domainConfig()
	editBegin()
	logBean = getMBean('/Log/' + cmo.getName())
	updateDomainLogSettings(logBean)
	editEnd()

	serversList = adminHome.getMBeansByType('Server')
	for s in serversList:
	instancename = s.getName()
	editBegin()
	logBean = getMBean('/Servers/' + instancename + '/Log/' + instancename)
	updateInstanceLogSettings(logBean)
	editEnd()
	exit(defaultAnswer='y')
except:
        exit(exitcode=2)

