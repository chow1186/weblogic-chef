import os
import sys
from java.io import FileInputStream

USERNAME = sys.argv[1]
ADMIN_URL = "t3://" + os.environ['ADMIN_HOST'] + ":" + os.environ['ADMIN_PORT']

propertiesStream = FileInputStream(os.environ['PROPERTIES_DIR']+"/users/"+USERNAME)
properties = Properties()
properties.load(propertiesStream)

GROUP=properties.get("GROUP")
PASSWORD=properties.get("PASSWORD")
DESCRIPTION=properties.get("DESCRIPTIONZ")

print "-----------------------------------------------------------------------------"
print "UserName: \t" + USERNAME
print "Group: \t" + GROUP
print "-----------------------------------------------------------------------------"


try:
	connect(url=ADMIN_URL)
	cd('/SecurityConfiguration/'+domainName+'/Realms/myrealm/AuthenticationProviders/DefaultAuthenticator')
	print "Checking for pre-existing username: " + USERNAME
	if cmo.userExists(USERNAME) != 1:
		print USERNAME + " does not exist. Creating..."
		cmo.createUser(USERNAME , PASSWORD , DESCRIPTION)
		cmo.addMemberToGroup(GROUP,USERNAME)
	else:
		print USERNAME + " already exists. Updating password.." 
		cmo.resetUserPassword(USERNAME,PASSWORD)
	disconnect()
	exit()
except:
	exit(exitcode=2)



