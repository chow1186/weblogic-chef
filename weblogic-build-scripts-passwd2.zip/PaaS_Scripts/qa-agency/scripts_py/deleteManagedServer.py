import os
import sys
from java.io import FileInputStream

INSTANCE_NAME = sys.argv[1]
readDomain(os.environ['DOMAIN_HOME'])

propertiesStream = FileInputStream(os.environ['PROPERTIES_DIR']+"/managed_instances/"+INSTANCE_NAME)
properties = Properties()
properties.load(propertiesStream)

ADMIN_URL = "t3://" + os.environ['ADMIN_HOST'] + ":" + os.environ['ADMIN_PORT']

print "-----------------------------------------------------------------------------"
print "Instance Name: \t" + INSTANCE_NAME
print "Listen Address: \t" + properties.get("LISTEN_ADDRESS")
print "Listen Port: \t" + properties.get("LISTEN_PORT")
print "-----------------------------------------------------------------------------"

try:
	connect(url=ADMIN_URL)
	edit()
	startEdit()
	cd('/')
	cd('/Servers/' + INSTANCE_NAME)
	cmo.setCluster(None)
	cmo.setMachine(None)
	editService.getConfigurationManager().removeReferencesToBean(getMBean('/Servers/' + INSTANCE_NAME))
	cd('/')
	cmo.destroyServer(getMBean('/Servers/' + INSTANCE_NAME))
	activate(block="true")
	disconnect()
        exit()
except:
        exit(exitcode=2)

