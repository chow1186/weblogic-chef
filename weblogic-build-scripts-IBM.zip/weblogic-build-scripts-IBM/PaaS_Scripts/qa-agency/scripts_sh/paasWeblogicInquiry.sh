#!/bin/sh

set -a
PROPERTIES_DIR=${PWD}/../properties
SCRIPTS_PY_DIR=${PWD}/../scripts_py
SCRIPTS_SH_DIR=${PWD}/../scripts_sh
. $PROPERTIES_DIR/domain.properties
# . $DOMAIN_HOME/bin/setDomainEnv.sh

OutputFile=/usr/tmp/`basename $0`.$$

(
  echo ""
  echo "PaaS Weblogic Inquiry results for host `hostname`"
  echo ""

  echo "Java Revision:"
  jdkversion=/usr/tmp/jdkversion.$$
  /tech/appl/java/jdk1.6.0/bin/java -version > ${jdkversion} 2>&1
  echo "  "`grep version ${jdkversion}`
  rm ${jdkversion}
  echo ""

  echo "Weblogic Revision:"
  echo "  "`${SCRIPTS_SH_DIR}/getWLSVersion.sh | grep WebLogic`
  echo ""

  echo "Weblogic Admin Server:"
  echo "  http://${ADMIN_HOST}:${ADMIN_PORT}/console/"
  echo ""

  echo "Weblogic Managed Instances (Name/Min/Max/Perm):"
  for f in ../properties/managed_instances/*_m*
  do
    MinHeap=`grep MIN_HEAP ${f} | sed -e s/MIN_HEAP=//`
    MaxHeap=`grep MAX_HEAP ${f} | sed -e s/MAX_HEAP=//`
    MaxPerm=`grep MAX_PERM ${f} | sed -e s/MAX_PERM=//`
    echo "  " `basename ${f}` ${MinHeap} ${MaxHeap} ${MaxPerm}
  done
) > ${OutputFile} 2>&1

cat ${OutputFile}

rm ${OutputFile}
