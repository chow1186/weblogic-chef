#!/bin/sh

set -a

JDBC_DATASOURCE_NAME=$1

PROPERTIES_DIR=${PWD}/../properties
SCRIPTS_PY_DIR=${PWD}/../scripts_py
SCRIPTS_SH_DIR=${PWD}/../scripts_sh

. $PROPERTIES_DIR/domain.properties

. $DOMAIN_HOME/bin/setDomainEnv.sh
#############################
echo "echoPROPERTIES_DIR"$PROPERTIES_DIR
echo "echoJDBC_DATASOURCE_NAME"$JDBC_DATASOURCE_NAME
echo "echoDOMAIN_NAME"$DOMAIN_HOME
############################

$JAVA_HOME/bin/java -classpath $WEBLOGIC_HOME/server/lib/weblogic.jar -Djava.security.egd=file:/dev/./urandom weblogic.WLST -skipWLSModuleScanning ${SCRIPTS_PY_DIR}/createJDBCPool.py $JDBC_DATASOURCE_NAME >> ${PAAS_LOGS_DIR}/wlst_createJDBCPool.log 2>&1

cd $SCRIPTS_SH_DIR
$SCRIPTS_SH_DIR/mask_password.sh $JDBC_DATASOURCE_NAME JDBC_PASSWORD
