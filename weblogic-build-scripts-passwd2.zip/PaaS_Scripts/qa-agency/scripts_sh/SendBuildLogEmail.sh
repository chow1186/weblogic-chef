#!/bin/sh

CLM_ENV=$1
CLM_ACTION=$2

DATE_TIME=`date +"%m-%d-%Y"`

PROPERTIES_DIR=${PWD}/../properties
PAAS_LOGS_DIR=${PWD}/../paas_logs

. ${PROPERTIES_DIR}/domain.properties

BUILD_LOG=`grep -i "$DATE_TIME" ${PAAS_LOGS_DIR}/build.log`
OutputFile="/usr/tmp/${DOMAIN_NAME}.tmp.$$"
cat > ${OutputFile} << EOF
DOMAIN NAME = ${DOMAIN_NAME}

ADMIN_URL="http://$ADMIN_HOST:$ADMIN_PORT/console"

$BUILD_LOG

EOF

EmailAddresses=""
if [ ${CLM_ENV} = "PROD" ]
then
  EmailAddresses="PaaSWeblogicProvisioning@thehartford.com, isdweblogic_teamapp@thehartford.com"
else
  EmailAddresses="PaaSWeblogicProvisioning@thehartford.com"
  # EmailAddresses="philip.jones@thehartford.com"
fi
DATE=`date`
ls -l ${OutputFile}
echo ADMIN_HOST ${ADMIN_HOST}
echo DOMAIN_NAME ${DOMAIN_NAME}
echo STATUS ${STATUS}
echo DATE ${DATE}
echo EmailAddresses ${EmailAddresses}
cat ${OutputFile} | /bin/mailx -r PaaSWeblogicProvisioning@thehartford.com -s "${ADMIN_HOST}: ${DOMAIN_NAME}: ${CLM_ACTION}: ${DATE}" ${EmailAddresses}
echo mailx returned $?

rm -rf ${OutputFile}

