import os
import sys
from java.io import FileInputStream

AUTHENTICATOR_NAME = sys.argv[1]
readDomain(os.environ['DOMAIN_HOME'])
DOMAIN_NAME=os.environ['DOMAIN_NAME']

propertiesStream = FileInputStream(os.environ['PROPERTIES_DIR']+"/authenticators/"+AUTHENTICATOR_NAME)
properties = Properties()
properties.load(propertiesStream)

AUTHENTICATOR_CLASS_NAME=properties.get("AUTHENTICATOR_CLASS_NAME")
AUTHENTICATOR_HOST=properties.get("AUTHENTICATOR_HOST")
AUTHENTICATOR_PORT=properties.get("AUTHENTICATOR_PORT")
AUTHENTICATOR_PRINCIPAL=properties.get("AUTHENTICATOR_PRINCIPAL")
AUTHENTICATOR_CREDENTIAL=properties.get("AUTHENTICATOR_CREDENTIAL")
AUTHENTICATOR_USER_BASE_DN=properties.get("AUTHENTICATOR_USER_BASE_DN")
AUTHENTICATOR_USER_NAME_ATTRIBUTE=properties.get("AUTHENTICATOR_USER_NAME_ATTRIBUTE")
AUTHENTICATOR_ALL_USERS_FILTER=properties.get("AUTHENTICATOR_ALL_USERS_FILTER")
AUTHENTICATOR_USER_OBJECT_CLASS=properties.get("AUTHENTICATOR_USER_OBJECT_CLASS")
AUTHENTICATOR_GROUP_BASE_DN=properties.get("AUTHENTICATOR_GROUP_BASE_DN")
AUTHENTICATOR_ADMIN_GROUP_NAME=properties.get("AUTHENTICATOR_ADMIN_GROUP_NAME")
AUTHENTICATOR_ALL_GROUPS_FILTER=properties.get("AUTHENTICATOR_ALL_GROUPS_FILTER")
AUTHENTICATOR_GROUP_FROM_NAME_FILTER=properties.get("AUTHENTICATOR_GROUP_FROM_NAME_FILTER")

ADMIN_URL = "t3://" + os.environ['ADMIN_HOST'] + ":" + os.environ['ADMIN_PORT']

print "-----------------------------------------------------------------------------"
print "AUTHENTICATOR NAME: \t" + AUTHENTICATOR_NAME
print "CLASS_NAME: \t" + AUTHENTICATOR_CLASS_NAME
print "HOST: \t" + AUTHENTICATOR_HOST
print "PORT: \t" + AUTHENTICATOR_PORT
print "PRINCIPAL: \t" + AUTHENTICATOR_PRINCIPAL
print "USER_BASE_DN: \t" + AUTHENTICATOR_USER_BASE_DN
print "USER_NAME_ATTRIBUTE: \t" + AUTHENTICATOR_USER_NAME_ATTRIBUTE
print "ALL_USERS_FILTER: \t" + AUTHENTICATOR_ALL_USERS_FILTER
print "USER_OBJECT_CLASS: \t" + AUTHENTICATOR_USER_OBJECT_CLASS
print "GROUP_BASE_DN: \t" + AUTHENTICATOR_GROUP_BASE_DN
print "ADMIN_GROUP_NAME: \t" + AUTHENTICATOR_ADMIN_GROUP_NAME
print "ALL_GROUPS_FILTER: \t" + AUTHENTICATOR_ALL_GROUPS_FILTER
print "GROUP_FROM_NAME_FILTER: \t" + AUTHENTICATOR_GROUP_FROM_NAME_FILTER
print "-----------------------------------------------------------------------------"


try:
	connect(url=ADMIN_URL)
	edit()
	startEdit()
	cd('/SecurityConfiguration/'+DOMAIN_NAME+'/Realms/myrealm')
	# In the following command, substitute the appropriate class type
	cmo.createAuthenticationProvider(AUTHENTICATOR_NAME,AUTHENTICATOR_CLASS_NAME)
	cd('/SecurityConfiguration/'+DOMAIN_NAME+'/Realms/myrealm/AuthenticationProviders/'+AUTHENTICATOR_NAME)
	cmo.setControlFlag('SUFFICIENT')
	cd('/SecurityConfiguration/'+DOMAIN_NAME+'/Realms/myrealm/AuthenticationProviders/'+AUTHENTICATOR_NAME)
	cmo.setHost(AUTHENTICATOR_HOST)
	cmo.setPort(int(AUTHENTICATOR_PORT))
	cmo.setPrincipal(AUTHENTICATOR_PRINCIPAL[1:-1])
	cmo.setSSLEnabled(true)
	set("Credential",AUTHENTICATOR_CREDENTIAL)
	cmo.setGroupBaseDN(AUTHENTICATOR_GROUP_BASE_DN[1:-1])
	cmo.setUserBaseDN(AUTHENTICATOR_USER_BASE_DN[1:-1])
	cmo.setUserNameAttribute(AUTHENTICATOR_USER_NAME_ATTRIBUTE)
	cmo.setAllUsersFilter(AUTHENTICATOR_ALL_USERS_FILTER[1:-1])
	cmo.setUserFromNameFilter('')
	cmo.setUserObjectClass(AUTHENTICATOR_USER_OBJECT_CLASS)
	cmo.setAllGroupsFilter(AUTHENTICATOR_ALL_GROUPS_FILTER[1:-1])
	cmo.setGroupFromNameFilter(AUTHENTICATOR_GROUP_FROM_NAME_FILTER[1:-1])
	#print AUTHENTICATOR_USER_BASE_DN[1:-1]
	#print AUTHENTICATOR_ALL_USERS_FILTER[1:-1]
	activate(block="true")
	disconnect()
	exit()
except:
	exit(exitcode=2)

