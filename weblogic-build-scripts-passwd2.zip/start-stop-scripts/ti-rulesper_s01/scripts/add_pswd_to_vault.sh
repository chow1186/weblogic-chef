#!/bin/bash
#####################################################################
#This script is used for storing passwords into JBoss vault         #
#Author - Teja JRK						    #
#version - 1.0							    #
#####################################################################
shopt -s extglob
echo -e  "You can store passwords into vault for below subsystems \n1)Data Source \n2)External JMS\n3)Mail Session\n4)LDAP"

VAULT_HOME=$(echo $PWD | awk -F "scripts" {'print $1'})/vault
PROPERTIES=$(echo $PWD | awk -F "scripts" {'print $1'} | xargs basename).properties
. ../configuration/$PROPERTIES
STORE_PSWD=$(echo kGllk/5HSzGw9p7J2DEXMny/d4x/WQ2TdKzXrUM7DbQ= | openssl enc -d -aes-256-cbc -a -nosalt -k PvsHwqK1USwrCkZ4N2CBaA==)
readChoice()
{
read -p "Please select a value from list above.[Eg: 1 for Data Source and 2 for External JMS]: " CHOICE
	if [[ $CHOICE != @(1|2|3|4) ]]; then
		echo -e "\nInvalid entry"
		readChoice
	fi

}
readPassword()
{       
	PASSWORD=""
	TEMP_PASSWORD=""
	read -s -p "Enter the password to be stored: " PASSWORD
        until [ "$PASSWORD" != "" ]
        do
                echo -e "\nPassword cannot be empty"
                read -s -p "Enter the password to be stored: " PASSWORD
        done
        echo -e ""
	read -s -p "Reenter the password to be stored: " TEMP_PASSWORD
        until [ "$PASSWORD" == "$TEMP_PASSWORD" ]
        do
                echo -e "\nPasswords do not match."
                readPassword
done
}

readValues()
{
	SUBSYSTEM=$1
	read -p "Enter $SUBSYSTEM Resource Name: " NAME
	until [ "$NAME" != "" ] 
	do
		echo -e "\nName cannot be empty. If you want to exit the tool press CTRL+c\n"
		read -p "Enter $SUBSYSTEM Resource Name: " NAME
	done
		readPassword	
}
storePassword(){
	VAULT_BLOCK=$1
	VAULT_ATTRIB=$2
	VAULT_SEC_ATTRIB=$3
	VALUE=$($JBOSS_HOME/bin/vault.sh --keystore ${VAULT_HOME}/default.vault --enc-dir ${VAULT_HOME} --keystore-password $STORE_PSWD -v vault --vault-block $VAULT_BLOCK  --attribute $VAULT_ATTRIB --sec-attr $VAULT_SEC_ATTRIB | grep "VAULT::" )
#echo -e "\e[1;31update yaml with $(tput bold) $VALUE $(tput sgr0)\e[0m"
	echo -e "Update password field in Yaml[Inclusing Quotes] with \e[1;31m'\\$\{$VALUE\}' $(tput sgr0) \e[0m"

}

readChoice


case "$CHOICE" in

1)readValues DataSource
  storePassword DS $NAME $PASSWORD
;;

2)readValues JMS
  storePassword JMS $NAME $PASSWORD
;;

3)readValues MailSession
  storePassword MS $NAME $PASSWORD

;;
4)readValues LDAPConnection
  storePassword LDAP $NAME $PASSWORD
;;

*) readChoice
;;
esac

echo ""

