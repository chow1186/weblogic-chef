# ##########################################################################
# Change Default Logging Configuration for the domain and all 
# Usage : setupLogging.py <Name of Properties file >
# #########################################################################
import sys
from java.io import FileInputStream

def editBegin():
	edit()
	startEdit()

def editEnd():
	save()
	activate(block="true")

def str2bool(v):
	return v.lower() in ("yes", "true", "t", "1")

def updateInstanceLogSettings(logBean):
	logBean.setRotationType(properties.get("ROTATION_TYPE"))
	logBean.setNumberOfFilesLimited(str2bool(properties.get("LIMIT_LOG_FILE_COUNT")))
	logBean.setFileCount(int(properties.get("LOG_FILE_COUNT")))
	logBean.setRotateLogOnStartup(str2bool(properties.get("ROTATE_LOG_ON_STARTUP")))
	logBean.setFileName(os.environ['DAILYLOG_DIRECTORY'] + '/' + logBean.getName() + '/' + logBean.getName() + '.log')
	logBean.setLoggerSeverity(properties.get("LOGGER_SEVERITY"))
	logBean.setDomainLogBroadcastSeverity(properties.get("DOMAIN_LOG_BROADCAST_SEVERITY"))
	logBean.setStdoutSeverity(properties.get("STDOUT_SEVERITY"))
	logBean.setLogFileSeverity(properties.get("LOG_FILE_SEVERITY"))
	logBean.setMemoryBufferSeverity(properties.get("MEMORY_BUFFER_SEVERITY"))
	logBean.setRedirectStdoutToServerLogEnabled(str2bool(properties.get("REDIRECT_STDOUT_LOGGING_ENABLED")))
	logBean.setRedirectStderrToServerLogEnabled(str2bool(properties.get("REDIRECT_STDERR_LOGGING_ENABLED")))
	httplogBean = getMBean('/Servers/' + logBean.getName() + '/WebServer/' + logBean.getName() + '/WebServerLog/' + logBean.getName())
	httplogBean.setRotationType(properties.get("ROTATION_TYPE"))
    	httplogBean.setNumberOfFilesLimited(str2bool(properties.get("LIMIT_LOG_FILE_COUNT")))
    	httplogBean.setFileCount(int(properties.get("LOG_FILE_COUNT")))
    	httplogBean.setRotateLogOnStartup(str2bool(properties.get("ROTATE_LOG_ON_STARTUP")))
    	httplogBean.setFileName(os.environ['DAILYLOG_DIRECTORY'] + '/' + logBean.getName() + '/' + 'access.log')


INSTANCE_NAME = sys.argv[1]

propertiesStream = FileInputStream(os.environ['PROPERTIES_DIR'] + "/instancelog.properties")
properties = Properties()
properties.load(propertiesStream)


ADMIN_URL = "t3://" + os.environ['ADMIN_HOST'] + ":" + os.environ['ADMIN_PORT']

print "-----------------------------------------------------------------------------"
print "Instance Name: \t" + INSTANCE_NAME
print "Instance Log Settings: "
input_file = open(os.environ['PROPERTIES_DIR'] + "/instancelog.properties", 'r')
for line in input_file:
    print line
input_file.close()
print "-----------------------------------------------------------------------------"


#Connect
try:
	connect(url=ADMIN_URL)
	editBegin()
	logBean = getMBean('/Servers/' + INSTANCE_NAME + '/Log/' + INSTANCE_NAME)
	updateInstanceLogSettings(logBean)
	editEnd()
	exit(defaultAnswer='y')
except:
	exit(exitcode=2,defaultAnswer='y')
