#!/bin/sh

STRING_TO_BE_DECRYPTED=$1
PASS_PHRASE=$2

echo $STRING_TO_BE_DECRYPTED | openssl enc -a -d -nosalt -pass pass:$PASS_PHRASE
