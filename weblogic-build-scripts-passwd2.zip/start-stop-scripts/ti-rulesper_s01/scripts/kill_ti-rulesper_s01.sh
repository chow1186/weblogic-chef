#!/bin/sh

ps auxww | grep -i nbv9jb  |  grep -i ti-rulesper_s01 | grep -i java | grep -v $0 | grep -v grep | awk '{print $2}' | xargs kill -9
