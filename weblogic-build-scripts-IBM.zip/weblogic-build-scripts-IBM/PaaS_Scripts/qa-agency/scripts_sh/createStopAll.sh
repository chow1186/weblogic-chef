#!/bin/sh

set -a

PROPERTIES_DIR=${PWD}/../properties

. $PROPERTIES_DIR/domain.properties

cd ${SCRIPTS_DIRECTORY}

StopAll="stopAll_${DOMAIN_NAME}.sh"
rm -f ${StopAll}
touch ${StopAll}
(
  echo "#!/bin/sh"
  echo ""
  echo cd ${SCRIPTS_DIRECTORY}
  for f in `ls stop_*sh | egrep -v admin`
  do
    echo ./${f}
  done
  for f in stop*admin.sh
  do
    echo ""
    echo ./${f}
  done
  echo ""
) > ${StopAll}
chmod 750 ${StopAll}
