#!/bin/sh

JBOSS_HOME=/tech/appl/Redhat/jboss-eap-7.1.1
STANDALONE_FILE=standalone-full-ha.xml
SERVER_NAME=ti-rulesper_s01
SERVER_HOME=/tech/appl/nbv9/jb_apps/ti-rulesper/ti-rulesper_s01

JAVA_HOME=/tech/appl/java/jdk1.8.0_162
JAVA=$JAVA_HOME/bin/java

export JAVA_HOME
export JAVA

export PATH=$PATH:$JAVA_HOME/bin

. $SERVER_HOME/configuration/$SERVER_NAME.properties

if [ "$JVM_STATE" == "active" ]; then

  /usr/bin/nohup $JBOSS_HOME/bin/standalone.sh -c ${STANDALONE_FILE} -P file://$SERVER_HOME/configuration/$SERVER_NAME.properties > /dev/null  2>&1 &
  echo "tail -f $SERVER_LOG_DIR/$SERVER_NAME.log"

else

  echo "This instance has been deactivated. This incident will be reported"
  USER=`who am i | cut -d " " -f1`
  echo "User $USER tried to start the JBOSS JVM - $SERVER_NAME on server $HOSTNAME which was marked as deactivated" | mailx -s "ALERT: Server start attempt on deactivated JVM -  $SERVER_NAME" CTOJBossSupportTeam@thehartford.com

fi


