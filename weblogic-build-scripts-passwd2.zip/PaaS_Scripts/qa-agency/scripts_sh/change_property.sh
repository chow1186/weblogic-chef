#!/bin/sh
# Replace a single property value in a file
#


PROPERTY_NAME=$1
PROPERTY_VALUE_NEW=$2
PROPERTY_FILE=$3

sed -i "s~$PROPERTY_NAME=[^ ]*~$PROPERTY_NAME=$PROPERTY_VALUE_NEW~g" $PROPERTY_FILE
