#!/bin/sh

set -a

PROPERTIES_DIR=${PWD}/../properties

. $PROPERTIES_DIR/domain.properties

cd ${SCRIPTS_DIRECTORY}

StartAll="startAll_${DOMAIN_NAME}.sh"
rm -f ${StartAll}
touch ${StartAll}
(
  echo "#!/bin/sh"
  echo ""
  echo cd ${SCRIPTS_DIRECTORY}
  for f in start*admin.sh
  do
    echo ./${f}
    echo sleep 20
  done
  for f in `ls start_*sh | egrep -v admin`
  do
    echo ./${f}
  done
  echo ""
) > ${StartAll}
chmod 750 ${StartAll}
