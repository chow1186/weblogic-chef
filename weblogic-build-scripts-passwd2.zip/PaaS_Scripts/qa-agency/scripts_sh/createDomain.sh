#!/bin/sh

set -a

PROPERTIES_DIR=${PWD}/../properties
SCRIPTS_PY_DIR=${PWD}/../scripts_py
SCRIPTS_SH_DIR=${PWD}/../scripts_sh
PAAS_LOGS_DIR=${PWD}/../paas_logs

. $PROPERTIES_DIR/domain.properties

DATE_TIME=`date +"[%m-%d-%Y] [%r]"`
echo -n "$DATE_TIME [`basename $0`] [Weblogic Version=$WEBLOGIC_VERSION] [JAVA_VERSION=$JAVA_VERSION] [User=$OS_USER] [DomainName=$DOMAIN_NAME] [DomainHome=$DOMAIN_HOME]" >> $PAAS_LOGS_DIR/build.log

$JAVA_HOME/bin/java -classpath $WEBLOGIC_HOME/server/lib/weblogic.jar -Djava.security.egd=file:/dev/./urandom weblogic.WLST -skipWLSModuleScanning ${SCRIPTS_PY_DIR}/createDomain.py >> ${PAAS_LOGS_DIR}/wlst_createDomain.log 2>&1


if [ $? -eq 2 ]
then
        echo -e "\t[Status=ERROR]" >> $PAAS_LOGS_DIR/build.log
	exit
else
        echo -e "\t[Status=SUCCESS]" >> $PAAS_LOGS_DIR/build.log
fi

./createDirectories.sh
./createBootProperties.sh
./createStartScript.sh `ls $PROPERTIES_DIR/admin_instance`
./createStopScript.sh `ls $PROPERTIES_DIR/admin_instance`
./createScriptsLinkFiles.sh

${DOMAIN_HOME}/scripts/start_${DOMAIN_NAME}_admin.sh
sleep 45

for user in `ls $PROPERTIES_DIR/users`
do
        ${SCRIPTS_SH_DIR}/createUser.sh $user
        ${SCRIPTS_SH_DIR}/createConfigKeyFiles.sh $user
done

./changeDomainLog.sh
./changeAdminLog.sh ${DOMAIN_NAME}_admin
./changeAdminUploadDir.sh

cp $PROPERTIES_DIR/planit.properties $DOMAIN_HOME/

################       Restart Admin at this point ##########
${DOMAIN_HOME}/scripts/stop_${DOMAIN_NAME}_admin.sh
${DOMAIN_HOME}/scripts/start_${DOMAIN_NAME}_admin.sh
$SCRIPTS_SH_DIR/mask_password.sh domain.properties ADMIN_PASSWORD
sleep 5

