#!/bin/sh
#########################################################################
#Description: Script is used for changing the password of default users,#
#	      provisioned for JBoss.					#
#Author : Teja JRK							#
#Version : 1.0								#
#########################################################################
shopt -s extglob
readAccount() {
	read -p "Enter the account for password change[jbadmin,jbmon,readonly,jbdeploy]: " JBOSS_ACCOUNT

	if [[ $JBOSS_ACCOUNT != @(jbadmin|jbmon|readonly|jbdeploy) ]]; then
		echo -e "Invalid entry. If you want to exit please press CTRL+c"
		readAccount
	fi
	

}
readPassword()
{
        PASSWORD=""
        TEMP_PASSWORD=""
        read -s -p "Enter the password to be stored: " PASSWORD
        until [ "$PASSWORD" != "" ]
        do
                echo -e "\nPassword cannot be empty"
                read -s -p "Enter the password to be stored: " PASSWORD
        done
        echo -e ""
        read -s -p "Reenter the password to be stored: " TEMP_PASSWORD
        until [ "$PASSWORD" == "$TEMP_PASSWORD" ]
        do
                echo -e "\nPasswords do not match."
                readPassword
done
}
echo -e "\n\e[1;31mNOTE:\e[0mYou can use this utility to change the password only for below accounts.These accounts are case sensitive. \njbadmin \njbmon \nreadonly \njbdeploy \n"
readAccount
echo -e "\e[1;31mNOTE:Password should be minimum 8 characters length and combination of upper and lower case with minum one special character and one number.\e[0m"
readPassword
export PASSWORD JBOSS_ACCOUNT

cat << EOF > encrypt.py

#!/usr/bin/python

import os
import re
from hashlib import md5
import sys

username = os.environ['JBOSS_ACCOUNT']
password = os.environ['PASSWORD']
def encrypt():
        h=md5(username+":ManagementRealm:"+password).hexdigest()
        print h
if re.match(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*(_|[^\w])).+$', password) and len(password) >= 8:
	encrypt()

EOF
EPASSWORD=`/usr/bin/python encrypt.py`


if [ "$EPASSWORD"x = "x" ]; then

        echo -e "\e[1;31mPassword didn't meet the requirements\e[0m"
        exit

fi

sed -i "/$JBOSS_ACCOUNT/c\\$JBOSS_ACCOUNT=$EPASSWORD" ../configuration/mgmt-users.properties

rm -f encrypt.py

echo -e "\nPassword has been updated succesfully"
