## (1) Get the attributes from the Node object on the server that the recipe is run on (Defined in environment)
os_user = node['weblogic']['os_user']
os_installer_group = node['weblogic']['os_installer_group']
user_home = File.join("/home", os_user)
nexus_url = node['weblogic']['nexus_url']
repository = node['weblogic']['repository']
group_id = node['weblogic']['group_id']
artifact_id = node['weblogic']['artifact_id']
version = node['weblogic']['version']
packaging = node['weblogic']['packaging']

## (2) Create the user/group used to install Weblogic and the WLS home directory
group os_installer_group do
action :create
append true
end

user os_user do
supports :manage_home => true
comment "Oracle user"
gid os_installer_group
home user_home
shell "/bin/bash"
end

## Create FMW Directory
directory node['weblogic']['oracle_home'] do
owner os_user
group os_installer_group
recursive true
action :create
end

## (3) Download the Weblogic installer from Nexus
installer_jar = File.join(user_home, "#{artifact_id}-#{version}.#{packaging}")
remote_file "download Oracle Weblogic Server" do
#source "#{nexus_url}?r=#{repository}&g=#{group_id}&a=#{artifact_id}&v=#{version}&p=#{packaging}"
source "file:///mnt/hgfs/vmwareData/Alan/SOA/fmw_12.1.3.0.0_wls.jar"
path installer_jar
owner os_user
group os_installer_group
end

## (4) Create OraInventory and Installer response files to allow silent install
ora_inventory_directory = File.join(user_home, "oraInventory")
ora_inventory_file = File.join( ora_inventory_directory, "ora_inventory.rsp")

directory ora_inventory_directory do
owner os_user
group os_installer_group
recursive true
action :create
end

template ora_inventory_file do
source "ora_inventory.rsp.erb"
owner os_user
group os_installer_group
variables(
ora_inventory_directory: ora_inventory_directory,
install_group: os_installer_group
)
owner os_user
group os_installer_group
end



## Create Response File
response_file = File.join(user_home, "wls-12c.rsp")
oracle_home = node['weblogic']['oracle_home']

template response_file do
source "wls-12c.rsp.erb"
variables(
oracle_home: oracle_home
)
owner os_user
group os_installer_group
end

## (5) Install Weblogic Server by executing the jar command defining the appropriate command line options to install silently
install_command = "#{node['weblogic']['java_home']}/bin/java -jar #{installer_jar} -silent -responseFile #{response_file} -invPtrLoc #{ora_inventory_file}"

execute install_command do
cwd user_home
user os_user
group os_installer_group
action :run
creates "#{oracle_home}/oraInst.loc"
end

