import os
import sys
from java.io import FileInputStream

readDomain(os.environ['DOMAIN_HOME'])
DOMAIN_NAME=os.environ['DOMAIN_NAME']

ADMIN_URL = "t3://" + os.environ['ADMIN_HOST'] + ":" + os.environ['ADMIN_PORT']

print "-----------------------------------------------------------------------------"
print "Setting Default Authenticator Control Flag to SUFFICIENT "
print "-----------------------------------------------------------------------------"


try:
	connect(url=ADMIN_URL)
	edit()
	startEdit()
	cd('/SecurityConfiguration/'+DOMAIN_NAME+'/Realms/myrealm/AuthenticationProviders/DefaultAuthenticator')
	cmo.setControlFlag('SUFFICIENT')
	activate(block="true")
	disconnect()
        exit()
except:
        exit(exitcode=2)

