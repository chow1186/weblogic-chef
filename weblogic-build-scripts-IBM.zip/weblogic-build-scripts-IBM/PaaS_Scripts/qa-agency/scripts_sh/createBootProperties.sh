#!/bin/sh

PROPERTIES_DIR=${PWD}/../properties
SCRIPTS_PY_DIR=${PWD}/../scripts_py
SCRIPTS_SH_DIR=${PWD}/../scripts_sh
PAAS_LOGS_DIR=${PWD}/../paas_logs

. $PROPERTIES_DIR/domain.properties

DATE_TIME=`date +"[%m-%d-%Y] [%r]"`
echo "$DATE_TIME [`basename $0`] [Username=$ADMIN_USERNAME] [DomainName=$DOMAIN_NAME] [DomainHome=$DOMAIN_HOME]" >> $PAAS_LOGS_DIR/build.log

cd $DOMAIN_HOME
echo "username=$ADMIN_USERNAME" > boot.properties
echo "password=$ADMIN_PASSWORD" >> boot.properties
chmod 700 boot.properties

