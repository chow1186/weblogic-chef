# weblogic_binary_install

TODO: Enter the cookbook description here.

reference: https://www.c2b2.co.uk/middleware-blog/installing-weblogic-with-chef.php

