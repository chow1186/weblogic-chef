#!/bin/sh

set -a

# Setup paths that hold the property files along with shell and python scripts
# Note that SCRIPTS_SH_DIR points to the same directory from where we are executing this file
# Has been added for readability and to have a seamless way of calling logMessage.sh
PROPERTIES_DIR=${PWD}/../properties
SCRIPTS_PY_DIR=${PWD}/../scripts_py
SCRIPTS_SH_DIR=${PWD}/../scripts_sh

# Source the domain.properties file so that we have everything that's needed for invoking python scripts
. $PROPERTIES_DIR/domain.properties

# Source domain.properties so that we can avoid passing passwords in the connect statement for WLST
. $DOMAIN_HOME/bin/setDomainEnv.sh

# PBJ $SCRIPTS_SH_DIR/logMessage.sh "PAAS-WL-1300" "Executing `basename $0`" $CHANGE_LOG

$JAVA_HOME/bin/java weblogic.utils.Versions -h

# PBJ $SCRIPTS_SH_DIR/logMessage.sh "PAAS-WL-1300" "Completed `basename $0`" $CHANGE_LOG