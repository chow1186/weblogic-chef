#!/bin/sh

STRING_TO_BE_ENCRYPTED=$1
PASS_PHRASE=$2

echo -n $STRING_TO_BE_ENCRYPTED | openssl enc -a -e  -nosalt -pass pass:$PASS_PHRASE
