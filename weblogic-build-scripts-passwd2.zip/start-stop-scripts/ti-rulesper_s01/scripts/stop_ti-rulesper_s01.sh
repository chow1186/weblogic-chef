#!/bin/sh

JBOSS_HOME=/tech/appl/Redhat/jboss-eap-7.1.1
STANDALONE_FILE=standalone-full-ha.xml
SERVER_NAME=ti-rulesper_s01
SERVER_HOME=/tech/appl/nbv9/jb_apps/ti-rulesper/ti-rulesper_s01

JAVA_HOME=/tech/appl/java/jdk1.8.0_162
JAVA=$JAVA_HOME/bin/java

export JAVA_HOME
export JAVA

export PATH=$PATH:$JAVA_HOME/bin

. $SERVER_HOME/configuration/$SERVER_NAME.properties
$JBOSS_HOME/bin/jboss-cli.sh --connect --controller=https-remoting://lad1jbahd2007:23605 command=:shutdown

ps auxww | grep -i nbv9jb  |  grep -i $SERVER_NAME | grep -i java | grep -v $0 | grep -v grep | awk '{print $2}' | xargs kill -9

exit 0

