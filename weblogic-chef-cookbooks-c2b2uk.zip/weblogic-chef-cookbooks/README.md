# weblogic_binary_install

TODO: Enter the cookbook description here.

reference links:-
 https://www.c2b2.co.uk/middleware-blog/installing-weblogic-with-chef.php
 https://docs.oracle.com/middleware/1212/core/OUIRF/response_file.htm#OUIRF393

 
