#!/bin/sh
set -a

PROPERTIES_DIR=${PWD}/../properties
SCRIPTS_PY_DIR=${PWD}/../scripts_py
SCRIPTS_SH_DIR=${PWD}/../scripts_sh

if [ ! -f "${PROPERTIES_DIR}/domain.properties" ]
then
	echo "domain.properties not found... Cannot continue"
	exit
fi

. $PROPERTIES_DIR/domain.properties

$JAVA_HOME/bin/java -classpath $WEBLOGIC_HOME/server/lib/weblogic.jar -Djava.security.egd=file:/dev/./urandom weblogic.WLST -skipWLSModuleScanning ${SCRIPTS_PY_DIR}/createDomain.py

./createDirectories.sh
./createBootProperties.sh
./createStartScript.sh `ls $PROPERTIES_DIR/admin_instance`
./createStopScript.sh `ls $PROPERTIES_DIR/admin_instance`

${DOMAIN_HOME}/scripts/start_${DOMAIN_NAME}_admin.sh 
sleep 20

for managed_instance in `ls $PROPERTIES_DIR/managed_instances/`
do
	./createManagedServer.sh $managed_instance
	./createStartScript.sh $managed_instance
	./createStopScript.sh $managed_instance
done
	
for user in `ls $PROPERTIES_DIR/users`
do
	${SCRIPTS_SH_DIR}/createUser.sh $user
	${SCRIPTS_SH_DIR}/createConfigKeyFiles.sh $user 
done

./changeDomainLog.sh
./changeInstanceLog.sh `ls $PROPERTIES_DIR/admin_instance`

################       Restart Admin at this point ##########
${DOMAIN_HOME}/scripts/stop_${DOMAIN_NAME}_admin.sh
${DOMAIN_HOME}/scripts/start_${DOMAIN_NAME}_admin.sh
sleep 20

for managed_instance in `ls $PROPERTIES_DIR/managed_instances/`
do
        ./changeInstanceLog.sh $managed_instance
	${DOMAIN_HOME}/scripts/start_${managed_instance}.sh
done



