#!/bin/sh
SERVER_NAME=prod-uwrepos_m01
SERVER_URL=t3://lad1wlahp2009:21402
DOMAIN_HOME=/tech/appl/cds9/user_projects/prod-uwrepos

. ${DOMAIN_HOME}/bin/setDomainEnv.sh

JAVA_OPTIONS="${JAVA_OPTIONS} -Djava.security.egd=file:/dev/./urandom -Dweblogic.system.BootIdentityFile=${DOMAIN_HOME}/boot.properties"

echo "import os" >"shutdown_$SERVER_NAME.py"
echo "connect(url='${SERVER_URL}')" >>"shutdown_$SERVER_NAME.py"
echo "shutdown('${SERVER_NAME}','Server','true',0,'true')" >>"shutdown_$SERVER_NAME.py"
echo "exit()" >>"shutdown_$SERVER_NAME.py"

echo "Stopping Weblogic Server..."
${JAVA_HOME}/bin/java -classpath ${CLASSPATH} ${JAVA_OPTIONS} weblogic.WLST shutdown_$SERVER_NAME.py 2>&1
echo "Done"

rm -f shutdown_$SERVER_NAME.py

