import os
import sys
from java.io import FileInputStream

print "-----------------------------------------------------------------------------"
print "Domain Name: \t" + os.environ['DOMAIN_NAME']
print "Domain Home: \t" + os.environ['DOMAIN_HOME']
print "Admin Username: \t" + os.environ['ADMIN_USERNAME']
print "Listen Address: \t" + os.environ['ADMIN_HOST']
print "Listen Port: \t" + os.environ['ADMIN_PORT']
print "Java Home: \t" + os.environ['JAVA_HOME']
print "-----------------------------------------------------------------------------"

try:
	readTemplate(os.environ['TEMPLATE_HOME'])

	cd('Servers/AdminServer')
	set('Name',os.environ['DOMAIN_NAME']+"_admin")
	set('ListenAddress',os.environ['ADMIN_HOST'])
	set('ListenPort',int(os.environ['ADMIN_PORT']))

	cd('/')
	cd('Security/base_domain/User/weblogic')
	set('Name',os.environ['ADMIN_USERNAME'])
	cmo.setPassword(os.environ['ADMIN_PASSWORD'])

	setOption('ServerStartMode','prod')
	setOption('JavaHome',os.environ['JAVA_HOME'])

	#cd('/SecurityConfiguration/base_domain/Realms/myrealm/AuthenticationProviders/DefaultAuthenticator')
	#cmo.setControlFlag('SUFFICIENT')

	writeDomain(os.environ['DOMAIN_HOME'])
	closeTemplate()
	exit()
except:
        exit(exitcode=2)



