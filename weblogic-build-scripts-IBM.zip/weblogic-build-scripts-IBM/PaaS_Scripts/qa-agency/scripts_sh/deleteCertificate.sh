#!/bin/sh

PROPERTIES_DIR=${PWD}/../properties
. $PROPERTIES_DIR/domain.properties

CERT_NAME=$1

. $PROPERTIES_DIR/certificates/$CERT_NAME

$JAVA_HOME/bin/keytool -delete -v -trustcacerts -alias ${ALIAS_NAME} -keystore ${KEY_STORE} -storepass ${STORE_PASSWORD}

