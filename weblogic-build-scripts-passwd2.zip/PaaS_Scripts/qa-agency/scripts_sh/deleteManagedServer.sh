#!/bin/sh

set -a

INSTANCE_NAME=$1

PROPERTIES_DIR=${PWD}/../properties
SCRIPTS_PY_DIR=${PWD}/../scripts_py
SCRIPTS_SH_DIR=${PWD}/../scripts_sh
PAAS_LOGS_DIR=${PWD}/../paas_logs

. $PROPERTIES_DIR/domain.properties

. $DOMAIN_HOME/bin/setDomainEnv.sh

DATE_TIME=`date +"[%m-%d-%Y] [%r]"`
echo -n "$DATE_TIME [`basename $0`] [Instance Name=$INSTANCE_NAME] " >> $PAAS_LOGS_DIR/build.log

$JAVA_HOME/bin/java -classpath $WEBLOGIC_HOME/server/lib/weblogic.jar -Djava.security.egd=file:/dev/./urandom weblogic.WLST -skipWLSModuleScanning ${SCRIPTS_PY_DIR}/deleteManagedServer.py $INSTANCE_NAME >> ${PAAS_LOGS_DIR}/wlst_deleteManagedServer.log 2>&1

if [ $? -eq 2 ]
then
        echo -e "\t[Status=ERROR]" >> $PAAS_LOGS_DIR/build.log
else
        echo -e "\t[Status=SUCCESS]" >> $PAAS_LOGS_DIR/build.log

	rm -rf $PROPERTIES_DIR/managed_instances/$INSTANCE_NAME
	rm -rf $DOMAIN_HOME/scripts/start_$INSTANCE_NAME.sh
	rm -rf $DOMAIN_HOME/scripts/stop_$INSTANCE_NAME.sh
	rm -rf $DOMAIN_HOME/../../scripts/start_$INSTANCE_NAME.sh
	rm -rf $DOMAIN_HOME/../../scripts/stop_$INSTANCE_NAME.sh
	rm -rf ${DAILYLOG_DIRECTORY}/$INSTANCE_NAME
	rm -rf ${DOMAIN_HOME}/servers/$INSTANCE_NAME

	cd ${SCRIPTS_SH_DIR} # Required for when running out of BladeLogic / CLM # PBJ
	for property_file in `find ../properties -type f | xargs grep -i $INSTANCE_NAME | cut -d':' -f1`
	do
		sed -i 's~$INSTANCE_NAME~~g' $property_file
	done
fi

