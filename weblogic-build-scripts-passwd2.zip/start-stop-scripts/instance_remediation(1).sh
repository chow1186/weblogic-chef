#Author - Vembu
#created on 07/07/2018
#This script remediates jboss instance
#Usage ./instance_remediation.sh <insance home> <instance name>
#!/bin/sh
#set java home
export JAVA_HOME=/tech/appl/java/jdk1.8.0_71
export PATH=$PATH:$JAVA_HOME/bin
#set jboss home
JBOSS_HOME=/tech/appl/Redhat/jboss-eap-7.0.9
echo JBOSS_HOME:$JBOSS_HOME
JBOSS_CLI=$JBOSS_HOME/bin/jboss-cli.sh
echo JBOSS_CLI:$JBOSS_CLI
INSTANCE_HOME=$1
echo INSTANCE_HOME:$INSTANCE_HOME
INSTANCE_NAME=$2
echo INSTANCE_NAME:$INSTANCE_NAME
NOW=`date +"%d%b%y%H%M"`
HOST_NAME=`hostname`

if grep -w https $INSTANCE_HOME/scripts/stop_$INSTANCE_NAME.sh; then
echo https protocol configured
else
JBOSS_PORT=`grep "jboss-cli" $INSTANCE_HOME/scripts/stop_$INSTANCE_NAME.sh | awk -F" " '{print $3}' | cut -d':' -f2`
echo JBOSS_PORT:$JBOSS_PORT
sed -i -e 's/'"$HOST_NAME"':'"$JBOSS_PORT"'/https-remoting:\/\/'"$HOST_NAME"':'"$((JBOSS_PORT+1))"'/g' $INSTANCE_HOME/scripts/stop_$INSTANCE_NAME.sh
echo Updated protocol and https port in stop script
fi
#Take backup of standalone-full-ha.xml
cp $INSTANCE_HOME/configuration/standalone-full-ha.xml $INSTANCE_HOME/configuration/standalone-full-ha.xml_$NOW
#Add ssl entry in security-realm=CustomRealm
$JBOSS_CLI -c --controller=$HOST_NAME:$JBOSS_PORT --command='/core-service=management/security-realm=CustomRealm/server-identity=ssl:add(alias=$\{HOST_NAME\}, keystore-path=/tech/appl/envctrl/JBAdminKeyStore/$\{HOST_NAME\}.jks,keystore-password=$\{VAULT::SSL::MGMTSSL::1\},enabled-protocols=["TLSv1.1 TLSv1.2"])'
echo Added ssl entry in security-realm=CustomRealm
#Remove http binding "management-http" and update as "management-https" 
$JBOSS_CLI -c --controller=$HOST_NAME:$JBOSS_PORT --command='/core-service=management/management-interface=http-interface:write-attribute(name=secure-socket-binding, value=management-https)'
echo Removed http binding "management-http" and update as "management-https"
#Update ExampleDS password as ${VAULT::DS::ExampleDS::1}
$JBOSS_CLI -c --controller=$HOST_NAME:$JBOSS_PORT --command='/subsystem=datasources/data-source=ExampleDS:write-attribute(name=password, value=$\{VAULT::DS::ExampleDS::1\})'
echo Updated ExampleDS password
#Update cognizant_jb_admin group in xml file
$JBOSS_CLI -c --controller=$HOST_NAME:$JBOSS_PORT --command='/core-service=management/access=authorization/role-mapping=SuperUser/include=COGNIZANT_JB_ADMINS:add(name=COGNIZANT_JB_ADMINS, realm=CustomRealm, type=GROUP)'
echo Updated cognizant_jb_admin group
#Disable deployment scanner
$JBOSS_CLI -c --controller=$HOST_NAME:$JBOSS_PORT --command='/subsystem=deployment-scanner/scanner=default:write-attribute(name="scan-enabled",value=false)'
echo Disabled deployment scanner
$JBOSS_CLI -c --controller=$HOST_NAME:$JBOSS_PORT --command='reload'
echo $INSTANCE_NAME restarted 
#Update protocol and https port in stop script
chmod -R 700 $INSTANCE_HOME/vault
