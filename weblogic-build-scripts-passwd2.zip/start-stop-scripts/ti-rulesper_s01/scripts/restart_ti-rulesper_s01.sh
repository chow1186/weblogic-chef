#!/bin/sh

cd /tech/appl/nbv9/jb_apps/ti-rulesper/ti-rulesper_s01/scripts
./stop_ti-rulesper_s01.sh

./start_ti-rulesper_s01.sh
