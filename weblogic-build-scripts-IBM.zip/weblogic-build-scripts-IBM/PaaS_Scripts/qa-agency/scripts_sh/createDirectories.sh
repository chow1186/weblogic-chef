#!/bin/sh

PROPERTIES_DIR=${PWD}/../properties
SCRIPTS_PY_DIR=${PWD}/../scripts_py
SCRIPTS_SH_DIR=${PWD}/../scripts_sh
PAAS_LOGS_DIR=${PWD}/../paas_logs

. $PROPERTIES_DIR/domain.properties
. $PROPERTIES_DIR/directories.properties

DATE_TIME=`date +"[%m-%d-%Y] [%r]"`
echo "$DATE_TIME [`basename $0`] [DomainName=$DOMAIN_NAME]" >> $PAAS_LOGS_DIR/build.log

for directory in `cat $PROPERTIES_DIR/directories.properties`
do
	echo $directory | awk -F"=" '{system("mkdir -p "$2)}'
done

mkdir -p $DAILYLOG_DIRECTORY/${DOMAIN_NAME}_admin
mkdir -p $DAILYLOG_DIRECTORY/${DOMAIN_NAME}_admin/heap_dumps

for instance in `ls  $PROPERTIES_DIR/managed_instances`
do
	if [ $instance != Managed_Instance_Template ]
	then
		mkdir -p $DAILYLOG_DIRECTORY/$instance
		mkdir -p $DAILYLOG_DIRECTORY/$instance/heap_dumps
		mkdir -p $DAILYLOG_DIRECTORY/$instance/app_logs
	fi
done

cd  $DOMAIN_HOME
ln -s ${DAILYLOG_DIRECTORY} logs

