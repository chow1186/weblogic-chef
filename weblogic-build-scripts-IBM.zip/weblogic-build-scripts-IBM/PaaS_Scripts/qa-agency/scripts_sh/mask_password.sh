#!/bin/sh

set -a

PROPERTY_FILE_BASE_NAME=$1
PROPERTY_NAME=$2

# Setup paths that hold the property files along with shell and python scripts
# Note that SCRIPTS_SH_DIR points to the same directory from where we are executing this file
# Has been added for readability and to have a seamless way of calling logMessage.sh
PROPERTIES_DIR=${PWD}/../properties
SCRIPTS_PY_DIR=${PWD}/../scripts_py
SCRIPTS_SH_DIR=${PWD}/../scripts_sh

# Source the  file so that we can retrieve the group and password
PROPERTY_FILE=`find ${PROPERTIES_DIR} -name $PROPERTY_FILE_BASE_NAME`

. $PROPERTIES_DIR/domain.properties

PROPERTY_VALUE_EXISTING=`sed '/^\#/d' $PROPERTY_FILE | grep "$PROPERTY_NAME"  | tail -n 1 | awk -F= '{ st = index($0,"=");print substr($0,st+1)}'`

ENCRYPTED_STRING=`$SCRIPTS_SH_DIR/encrypt_string.sh $PROPERTY_VALUE_EXISTING $DOMAIN_NAME`

$SCRIPTS_SH_DIR/change_property.sh $PROPERTY_NAME $ENCRYPTED_STRING $PROPERTY_FILE
