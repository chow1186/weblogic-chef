import os
import sys
from java.io import FileInputStream

MAIL_SESSION_NAME = sys.argv[1]
readDomain(os.environ['DOMAIN_HOME'])

propertiesStream = FileInputStream(os.environ['PROPERTIES_DIR']+"/mail_sessions/"+MAIL_SESSION_NAME)
properties = Properties()
properties.load(propertiesStream)

SESSION_NAME=properties.get("SESSION_NAME")
SESSION_JNDI_NAME=properties.get("SESSION_JNDI_NAME")
SESSION_PROPS=properties.get("SESSION_PROPS")
SESSION_TARGETS=properties.get("SESSION_TARGETS")

ADMIN_URL = "t3://" + os.environ['ADMIN_HOST'] + ":" + os.environ['ADMIN_PORT']

try:
	connect(url=ADMIN_URL)
	edit()
	startEdit()
	cd('/')

	LOOKUP_RESULT = cmo.lookupMailSession(SESSION_NAME)

	if LOOKUP_RESULT != None:
		print SESSION_NAME + ' exists. Destorying existing session'
		cmo.destroyMailSession(LOOKUP_RESULT)

	cmo.createMailSession(SESSION_NAME)
	cd('/MailSessions/'+SESSION_NAME)
	cmo.setJNDIName(SESSION_JNDI_NAME)
	cmo.setProperties(makePropertiesObject(SESSION_PROPS))
	TARGETS_LIST = SESSION_TARGETS.split(',')
	for target in TARGETS_LIST:
	print target.strip()
	svr = getMBean("/Servers/"+target.strip())
	cmo.addTarget(svr)

	activate(block="true")
	disconnect()
        exit()
except:
        exit(exitcode=2)
