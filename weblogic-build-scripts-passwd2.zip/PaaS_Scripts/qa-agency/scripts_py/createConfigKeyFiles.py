import os
import sys
from java.io import FileInputStream

USERNAME = sys.argv[1]
PASSWORD = sys.argv[2]
DOMAIN_NAME = sys.argv[3]

ADMIN_URL = "t3://" + os.environ['ADMIN_HOST'] + ":" + os.environ['ADMIN_PORT']
CONFIG_FILE = os.environ['CONFIG_KEY_DIRECTORY'] + "/" + DOMAIN_NAME + "_" + USERNAME + ".cfg"
KEY_FILE = os.environ['CONFIG_KEY_DIRECTORY'] + "/" + DOMAIN_NAME + "_" + USERNAME + ".key"

print "-----------------------------------------------------------------------------"
print "Username: \t" + USERNAME
print "Config File: \t" + CONFIG_FILE
print "Key File: \t" + KEY_FILE
print "-----------------------------------------------------------------------------"

try:
	connect(USERNAME, PASSWORD, ADMIN_URL)
	storeUserConfig(CONFIG_FILE, KEY_FILE)
	disconnect()
        exit()
except:
        exit(exitcode=2)

