import os
import sys
from java.io import FileInputStream

GROUP_NAME = sys.argv[1]
DOMAIN_NAME=os.environ['DOMAIN_NAME']

propertiesStream = FileInputStream(os.environ['PROPERTIES_DIR']+"/groups/"+GROUP_NAME)
properties = Properties()
properties.load(propertiesStream)

GROUP_ROLE=properties.get("GROUP_ROLE")

ADMIN_URL = "t3://" + os.environ['ADMIN_HOST'] + ":" + os.environ['ADMIN_PORT']

print "-----------------------------------------------------------------------------"
print "Group Name: \t" + GROUP_NAME
print "Group Role: \t" + GROUP_ROLE
print "-----------------------------------------------------------------------------"

try:
	connect(url=ADMIN_URL)
	cd('/SecurityConfiguration/'+DOMAIN_NAME+'/Realms/myrealm/RoleMappers/XACMLRoleMapper')
	EXISTING_EXPR=cmo.getRoleExpression('',GROUP_ROLE)
	print "Existing Expression: \t" + EXISTING_EXPR
	NEW_EXPRESSION="Grp(" + GROUP_NAME + ")" +  "|" + EXISTING_EXPR
	print "New Expression: \t" + NEW_EXPRESSION
	cmo.setRoleExpression('',GROUP_ROLE,NEW_EXPRESSION)
	disconnect()
        exit()
except:
        exit(exitcode=2)

