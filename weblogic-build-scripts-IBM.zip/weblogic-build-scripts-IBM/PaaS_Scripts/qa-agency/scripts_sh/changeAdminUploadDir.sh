#!/bin/sh


#!/bin/sh

set -a

# Setup paths that hold the property files along with shell and python scripts
# Note that SCRIPTS_SH_DIR points to the same directory from where we are executing this file
# Has been added for readability and to have a seamless way of calling logMessage.sh
PROPERTIES_DIR=${PWD}/../properties
SCRIPTS_PY_DIR=${PWD}/../scripts_py
SCRIPTS_SH_DIR=${PWD}/../scripts_sh
PAAS_LOGS_DIR=${PWD}/../paas_logs

# Source the domain.properties file so that we have everything that's needed for invoking python scripts
. $PROPERTIES_DIR/domain.properties

DATE_TIME=`date +"[%m-%d-%Y] [%r]"`
echo -n "$DATE_TIME [`basename $0`] [DomainName=$DOMAIN_NAME]" >> $PAAS_LOGS_DIR/build.log

# Source domain.properties so that we can avoid passing passwords in the connect statement for WLST
. $DOMAIN_HOME/bin/setDomainEnv.sh

$JAVA_HOME/bin/java -classpath $WEBLOGIC_HOME/server/lib/weblogic.jar -Djava.security.egd=file:/dev/./urandom weblogic.WLST -skipWLSModuleScanning ${SCRIPTS_PY_DIR}/changeAdminUploadDir.py >> ${PAAS_LOGS_DIR}/wlst_changeAdminUploadDir.log 2>&1 

if [ $? -eq 2 ]
then
        echo -e "\t[Status=ERROR]" >> $PAAS_LOGS_DIR/build.log
else
        echo -e "\t[Status=SUCCESS]" >> $PAAS_LOGS_DIR/build.log
fi


