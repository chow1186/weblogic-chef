#
# Cookbook:: weblogic_binary_install
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.
