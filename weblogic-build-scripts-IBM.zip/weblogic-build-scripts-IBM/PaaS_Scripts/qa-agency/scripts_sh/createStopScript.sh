#!/bin/sh

PROPERTIES_DIR=${PWD}/../properties
SCRIPTS_PY_DIR=${PWD}/../scripts_py
SCRIPTS_SH_DIR=${PWD}/../scripts_sh
PAAS_LOGS_DIR=${PWD}/../paas_logs

. $PROPERTIES_DIR/domain.properties

instance_name=$1
INSTANCE_FILE=`find ${PROPERTIES_DIR} -name $instance_name`

DATE_TIME=`date +"[%m-%d-%Y] [%r]"`
echo "$DATE_TIME [`basename $0`] [InstanceName=$instance_name]" >> $PAAS_LOGS_DIR/build.log

. ${INSTANCE_FILE}
INSTANCE_URL="t3://${LISTEN_ADDRESS}:${LISTEN_PORT}"

sed -e "s^server_name_val^$instance_name^g" -e "s^server_url_val^$INSTANCE_URL^g" -e "s^domain_home_val^$DOMAIN_HOME^g" stopScriptTemplate > stop_${instance_name}.sh
chmod 750 stop_${instance_name}.sh
mv stop_${instance_name}.sh $SCRIPTS_DOMAIN_DIRECTORY

