#!/bin/sh

set -a

USERNAME=$1

PROPERTIES_DIR=${PWD}/../properties
SCRIPTS_PY_DIR=${PWD}/../scripts_py
SCRIPTS_SH_DIR=${PWD}/../scripts_sh
PAAS_LOGS_DIR=${PWD}/../paas_logs

. $PROPERTIES_DIR/domain.properties

. $DOMAIN_HOME/bin/setDomainEnv.sh

DATE_TIME=`date +"[%m-%d-%Y] [%r]"`
echo -n "$DATE_TIME [`basename $0`] [User=$USERNAME] [DomainName=$DOMAIN_NAME]" >> $PAAS_LOGS_DIR/build.log

$JAVA_HOME/bin/java -classpath $WEBLOGIC_HOME/server/lib/weblogic.jar -Djava.security.egd=file:/dev/./urandom weblogic.WLST -skipWLSModuleScanning ${SCRIPTS_PY_DIR}/createUser.py $USERNAME >> ${PAAS_LOGS_DIR}/wlst_createUser.log 2>&1

if [ $? -eq 2 ]
then
	echo -e "\t[Status=ERROR]" >> $PAAS_LOGS_DIR/build.log
	exit
else
	echo -e "\t[Status=SUCCESS]" >> $PAAS_LOGS_DIR/build.log
fi

cd $SCRIPTS_SH_DIR
$SCRIPTS_SH_DIR/mask_password.sh $USERNAME PASSWORD

