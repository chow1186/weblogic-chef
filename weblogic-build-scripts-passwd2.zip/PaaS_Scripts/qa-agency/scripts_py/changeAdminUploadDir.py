import os
import sys
from java.io import FileInputStream

readDomain(os.environ['DOMAIN_HOME'])
DOMAIN_NAME=os.environ['DOMAIN_NAME']
UPLOAD_DIRECTORY=os.environ['CODEBASE_DIRECTORY']+'/upload'


ADMIN_URL="t3://" + os.environ['ADMIN_HOST'] + ":" + os.environ['ADMIN_PORT']

print "-----------------------------------------------------------------------------"
print "Upload Directory: \t" + UPLOAD_DIRECTORY
print "-----------------------------------------------------------------------------"


try:
	connect(url=ADMIN_URL)
	edit()
	startEdit()
	cd('/Servers/'+DOMAIN_NAME+'_admin')
	cmo.setUploadDirectoryName(UPLOAD_DIRECTORY)
	activate(block="true")
	disconnect()
	exit()
except:
	exit(exitcode=2)

